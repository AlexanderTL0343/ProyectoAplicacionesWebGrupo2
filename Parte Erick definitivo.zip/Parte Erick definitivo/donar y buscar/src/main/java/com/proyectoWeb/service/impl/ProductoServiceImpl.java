package com.proyectoWeb.service.impl;

import com.proyectoWeb.dao.ProductoDao;
import com.proyectoWeb.domain.Producto;
import com.proyectoWeb.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoServiceImpl implements ProductoService {

    @Autowired
    private ProductoDao productoDao;

    @Override
    public List<Producto> getProductos() {
        return productoDao.findAll();
    }

    @Override
    public Producto getProducto(Producto producto) {
        return productoDao.findById(producto.getIdProducto()).orElse(null);
    }

    @Override
    public List<Producto> buscarPorDescripcion(String descripcion) {
        return productoDao.findByDescripcionContainingIgnoreCase(descripcion);
    }
}
