package com.proyectoWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
