
package com.proyectoWeb.dao;

import com.proyectoWeb.domain.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CategoriaDao extends JpaRepository<Categoria,Long>{

}
